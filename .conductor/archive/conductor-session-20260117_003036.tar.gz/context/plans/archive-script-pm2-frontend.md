# План: Адаптация Archive Script для остановки PM2 Frontend

## Задача
Модифицировать `.conductor/scripts/archive.sh` чтобы он автоматически останавливал PM2 frontend процесс (development или production) при архивации сессии в Conductor.

## Проблема
При архивации через кнопку "Архивировать" в Conductor:
- Скрипт `archive.sh` сохраняет только файлы сессии (.context/, _bmad-output/)
- PM2 процесс продолжает работать на порту 3100
- Это может вызвать конфликты при переключении между worktrees

## Решение
Добавить в `archive.sh` автоматическую остановку PM2 frontend процессов перед архивацией.

## Файлы для изменения

### 1. `.conductor/scripts/archive.sh`
**Изменения:**
- Добавить загрузку `utils.sh` для доступа к PM2 функциям
- Добавить секцию "Phase 0: Stop PM2 Processes" перед архивацией
- Использовать существующие функции из `utils.sh`:
  - `pm2_installed()` - проверка установлен ли PM2
  - `get_pm2_frontend_name()` - определить какой процесс запущен (dev или prod)
  - `stop_pm2_frontend()` - остановить процесс

### 2. `.conductor/scripts/lib/utils.sh` (если нужно)
**Проверить:** все ли функции корректно работают
- `get_pm2_frontend_name()` - уже умеет определять dev vs production
- `stop_pm2_frontend()` - уже останавливает процесс и сохраняет PM2 dump

## Детальная реализация

### Изменения в `archive.sh`:

```bash
# После секции с цветами и перед основным выполнением добавить:

# Load shared utilities for PM2 functions
source "$SCRIPT_DIR/lib/utils.sh"

# Добавить новую секцию после "cd $PROJECT_ROOT" и перед архивацией:

# =============================================================================
# PHASE 0: Stop PM2 Processes
# =============================================================================
echo "🛑 Checking for running PM2 processes..."

if pm2_installed; then
    if pm2_frontend_running; then
        FRONTEND_NAME=$(get_pm2_frontend_name)
        if [ -n "$FRONTEND_NAME" ]; then
            echo "📦 Stopping PM2 frontend ($FRONTEND_NAME) before archive..."
            stop_pm2_frontend
            log_success "PM2 frontend stopped, port 3100 freed"
        fi
    else
        log_info "No PM2 frontend processes running"
    fi
else
    log_info "PM2 not installed, skipping PM2 shutdown"
fi

echo ""
```

## Проверка логики

### Как это работает:

1. **Определение типа процесса:**
   - `get_pm2_frontend_name()` проверяет PM2 список
   - Возвращает `wb-repricer-frontend-dev` для development
   - Возвращает `wb-repricer-frontend` для production
   - Возвращает пустую строку если ничего не запущено

2. **Остановка процесса:**
   - `stop_pm2_frontend()` вызывает `pm2 stop <app_name>`
   - Выполняет `pm2 save --force` для сохранения состояния
   - Освобождает порт 3100

3. **Порядок действий:**
   - Остановить PM2 → Подождать 2 секунды → Создать архив → Очистить старые архивы

## Веревификация (Testing)

### Шаг 1: Проверить текущее состояние
```bash
pm2 list                    # Должен показывать wb-repricer-frontend-dev online
lsof -ti:3100              # Должен показывать PID процесса
```

### Шаг 2: Протестировать archive.sh
```bash
cd /Users/r2d2/conductor/workspaces/frontend/dakar
bash .conductor/scripts/archive.sh
```

### Ожидаемый результат:
1. Скрипт определяет что PM2 процесс запущен
2. Останавливает `wb-repricer-frontend-dev`
3. Порт 3100 освобождается
4. Создаётся архив сессии

### Шаг 3: Проверить после архивации
```bash
pm2 list                    # Должен показывать stopped или пустой список
lsof -ti:3100              # Должен быть пуст (порт свободен)
curl http://localhost:3100  # Должен fail (Connection refused)
```

### Шаг 4: Проверить restart
```bash
bash .conductor/scripts/run.sh
pm2 list                    # Должен снова показывать online
curl http://localhost:3100  # Должен работать
```

## Критические файлы

| Файл | Действие |
|------|----------|
| `.conductor/scripts/archive.sh` | Изменить - добавить PM2 остановку |
| `.conductor/scripts/lib/utils.sh` | Только чтение - использовать существующие функции |
| `ecosystem.config.js` | Только чтение - для понимания PM2 конфигурации |

## Возможные проблемы и решения

### Проблема 1: PM2 не установлен
**Решение:** Скрипт корректно обрабатывает это через `pm2_installed()` и пропускает остановку

### Проблема 2: Несколько worktrees с PM2
**Решение:** Функция `pm2_process_cwd_matches()` проверяет CWD процесса, но в текущей реализации мы останавливаем любой frontend процесс на порту 3100

### Проблема 3: Process не останавливается
**Решение:** Можно добавить force kill через lsof как fallback:
```bash
# Fallback: Kill any process on port 3100
port_pid=$(lsof -ti:3100 -sTCP:LISTEN -t 2>/dev/null | head -n1)
if [ -n "$port_pid" ]; then
    log_info "Force killing process on port 3100..."
    kill "$port_pid" 2>/dev/null || true
fi
```

## Итог

**Что будет сделано:**
1. Модифицирован `.conductor/scripts/archive.sh` с добавлением секции остановки PM2
2. Использованы существующие функции из `utils.sh` (избыточного кода не будет)
3. При архивации через Conductor кнопку - PM2 процесс автоматически остановится

**Файл изменений:**
- `/Users/r2d2/conductor/workspaces/frontend/dakar/.conductor/scripts/archive.sh`
